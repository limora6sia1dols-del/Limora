import { Hero } from "@/components/Hero";
import { Layout } from "@/components/Layout";

export function Home() {
  return (
    <Layout>
      <Hero />
    </Layout>
  );
}
